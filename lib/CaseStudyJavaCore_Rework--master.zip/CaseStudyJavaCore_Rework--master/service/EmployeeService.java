package service;

import Models.Employee;

import java.util.List;

public interface EmployeeService {
    List<Employee> getAllListEmployee();
}
