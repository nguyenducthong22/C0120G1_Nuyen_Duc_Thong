package service;

import Models.Employee;

public interface FilingCabinetsService {
    Employee findEmployeeById(String id);
}
