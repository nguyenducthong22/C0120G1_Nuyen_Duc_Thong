package service;

import Models.Customer;

public interface CustomerService {
    Customer addNewCustomer();
}
