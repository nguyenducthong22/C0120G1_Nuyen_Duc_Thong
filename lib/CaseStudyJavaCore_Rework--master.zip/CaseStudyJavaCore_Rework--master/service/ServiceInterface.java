package service;

import Models.Service;

public interface ServiceInterface {
    Service addNewService();
}
